```markdown
# Larry's Delight — React + Tailwind website

This repository contains a small React + TailwindCSS website for Larry's Delight, a company producing healthy fruit drinks. It includes four pages: Home, Products, About, and Contact.

Features:
- Vite + React
- Tailwind CSS
- React Router (4 pages)
- Simple responsive layout with header and footer
- Product listing components and a contact form (demo)

Getting started:

1. Install dependencies
   npm install

2. Initialize Tailwind (already configured):
   No additional step needed — the project includes Tailwind config and PostCSS setup.

3. Run the dev server:
   npm run dev

4. Build:
   npm run build
   npm run preview

Notes:
- Images use Unsplash placeholder URLs. Replace with your own product photography in `src/pages/*` or `public/assets`.
- The contact form is a demo (alerts). Hook it up to your backend or a service like Formspree, Netlify Forms, or a custom API.
- Update brand colors in `tailwind.config.cjs` under theme.extend.colors.

If you'd like, I can:
- Commit these files to your repository.
- Add deployment config (GitHub Pages or Vercel).
- Implement a simple cart/checkout flow or a CMS-backed product list.

Created for: Larry's Delight — natural healthy fruit drinks.
```