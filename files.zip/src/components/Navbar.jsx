import React, { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const active = ({ isActive }) =>
    isActive ? 'text-primary font-semibold' : 'text-gray-700 hover:text-primary'

  return (
    <header className="bg-white shadow-sm">
      <div className="container flex items-center justify-between py-4">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold">
            LD
          </div>
          <div>
            <h1 className="text-lg font-semibold">Larry's Delight</h1>
            <p className="text-xs text-gray-500 -mt-1">Natural healthy fruit drinks</p>
          </div>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          <NavLink to="/" className={active}>Home</NavLink>
          <NavLink to="/products" className={active}>Products</NavLink>
          <NavLink to="/about" className={active}>About</NavLink>
          <NavLink to="/contact" className={active}>Contact</NavLink>
          <a href="#order" className="ml-4 inline-block bg-primary text-white px-4 py-2 rounded-md hover:opacity-95">Order Now</a>
        </nav>

        <div className="md:hidden">
          <button onClick={() => setOpen(v => !v)} aria-label="Toggle menu" className="p-2 rounded-md border">
            <svg className="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
              {open ? (
                <path fillRule="evenodd" d="M6 4l8 8M14 4L6 12" clipRule="evenodd" />
              ) : (
                <path fillRule="evenodd" d="M3 5h14M3 10h14M3 15h14" clipRule="evenodd" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t">
          <div className="container py-4 flex flex-col gap-3">
            <NavLink onClick={() => setOpen(false)} to="/" className={active}>Home</NavLink>
            <NavLink onClick={() => setOpen(false)} to="/products" className={active}>Products</NavLink>
            <NavLink onClick={() => setOpen(false)} to="/about" className={active}>About</NavLink>
            <NavLink onClick={() => setOpen(false)} to="/contact" className={active}>Contact</NavLink>
            <a href="#order" className="mt-2 inline-block bg-primary text-white px-4 py-2 rounded-md w-max">Order Now</a>
          </div>
        </div>
      )}
    </header>
  )
}