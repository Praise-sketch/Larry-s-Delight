import React from 'react'
import { Link } from 'react-router-dom'

export default function Hero() {
  return (
    <section className="bg-white py-16">
      <div className="container grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h2 className="text-4xl md:text-5xl font-extrabold leading-tight">
            Natural. Refreshing. Delicious.
          </h2>
          <p className="mt-6 text-gray-600 max-w-xl">
            Larry's Delight crafts healthy fruit drinks using real fruit, no artificial flavors, and sustainable practices. Perfect for daily refreshment or stocking your store.
          </p>
          <div className="mt-8 flex gap-4">
            <Link to="/products" className="bg-primary text-white px-6 py-3 rounded-md shadow">View Products</Link>
            <Link to="/contact" className="border border-primary text-primary px-6 py-3 rounded-md">Get in Touch</Link>
          </div>
          <div id="order" className="mt-6 text-sm text-gray-500">Wholesale & retail available — shipping nationwide.</div>
        </div>
        <div className="flex justify-center">
          <img className="rounded-xl shadow-lg w-[420px] object-cover" src="https://images.unsplash.com/photo-1546069901-eacef0df6022?q=80&w=1400&auto=format&fit=crop&ixlib=rb-4.0.3&s=9f3b3405d1b1c2b9f1d8f316fc2c7b4d" alt="fresh fruit drinks" />
        </div>
      </div>
    </section>
  )
}