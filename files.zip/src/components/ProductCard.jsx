import React from 'react'

export default function ProductCard({ product }) {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <img src={product.image} alt={product.name} className="w-full h-48 object-cover" />
      <div className="p-4">
        <h3 className="font-semibold">{product.name}</h3>
        <p className="text-sm text-gray-600 mt-2">{product.description}</p>
        <div className="mt-4 flex items-center justify-between">
          <div className="text-lg font-bold text-primary">{product.price}</div>
          <button className="bg-accent text-white px-3 py-1 rounded-md text-sm hover:opacity-95">Add to cart</button>
        </div>
      </div>
    </div>
  )
}