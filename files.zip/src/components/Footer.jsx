import React from 'react'
import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="bg-white border-t mt-12">
      <div className="container py-8 flex flex-col md:flex-row justify-between items-start gap-6">
        <div>
          <h3 className="text-xl font-semibold">Larry's Delight</h3>
          <p className="text-gray-600 mt-2 max-w-sm">
            Producing and delivering natural, healthy fruit drinks made from locally sourced fruits.
          </p>
        </div>
        <div className="flex gap-10">
          <div>
            <h4 className="font-medium">Company</h4>
            <ul className="mt-2 text-gray-600">
              <li><Link to="/about">About</Link></li>
              <li><Link to="/products">Products</Link></li>
              <li><Link to="/contact">Contact</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium">Contact</h4>
            <p className="mt-2 text-gray-600">Email: hello@larrysdelight.example</p>
            <p className="text-gray-600">Phone: +1 (555) 123-4567</p>
          </div>
        </div>
      </div>
      <div className="bg-gray-50 py-3">
        <div className="container text-sm text-gray-500">© {new Date().getFullYear()} Larry's Delight. All rights reserved.</div>
      </div>
    </footer>
  )
}