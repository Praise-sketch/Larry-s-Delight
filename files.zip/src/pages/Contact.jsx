import React, { useState } from 'react'

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value })
  const handleSubmit = e => {
    e.preventDefault()
    // This demo doesn't have a backend. In a real app, send form to API.
    alert('Thanks! Your message has been received (demo).')
    setForm({ name: '', email: '', message: '' })
  }

  return (
    <section className="py-12">
      <div className="container max-w-2xl">
        <h2 className="text-3xl font-semibold">Contact Us</h2>
        <p className="text-gray-600 mt-2">Questions about wholesale, ingredients, or placing an order? Get in touch.</p>

        <form onSubmit={handleSubmit} className="mt-6 bg-white p-6 rounded-lg shadow-sm">
          <label className="block">
            <span className="text-sm font-medium">Name</span>
            <input required name="name" value={form.name} onChange={handleChange} className="mt-1 block w-full border rounded-md px-3 py-2" placeholder="Your name" />
          </label>

          <label className="block mt-4">
            <span className="text-sm font-medium">Email</span>
            <input required type="email" name="email" value={form.email} onChange={handleChange} className="mt-1 block w-full border rounded-md px-3 py-2" placeholder="you@example.com" />
          </label>

          <label className="block mt-4">
            <span className="text-sm font-medium">Message</span>
            <textarea required name="message" value={form.message} onChange={handleChange} className="mt-1 block w-full border rounded-md px-3 py-2" rows="5" placeholder="How can we help?"></textarea>
          </label>

          <div className="mt-4 flex items-center justify-between">
            <button type="submit" className="bg-primary text-white px-5 py-2 rounded-md">Send Message</button>
            <div className="text-sm text-gray-500">Or email us at hello@larrysdelight.example</div>
          </div>
        </form>
      </div>
    </section>
  )
}