import React from 'react'

export default function About() {
  return (
    <section className="py-12">
      <div className="container">
        <h2 className="text-3xl font-semibold">About Larry's Delight</h2>
        <p className="text-gray-600 mt-4 max-w-3xl">
          Larry's Delight is committed to producing natural, healthy fruit drinks using responsibly sourced fruits.
          Our mission is to offer refreshing beverages free from artificial flavors and unnecessary additives while supporting local farmers.
        </p>

        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold">Quality Ingredients</h3>
            <p className="text-gray-600 mt-2">We use ripe fruits, minimal sweeteners, and natural preservation techniques.</p>
          </div>
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold">Sustainability</h3>
            <p className="text-gray-600 mt-2">Packaging and sourcing practices that minimize environmental impact.</p>
          </div>
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold">Community</h3>
            <p className="text-gray-600 mt-2">Partnering with local growers to strengthen the local economy.</p>
          </div>
        </div>
      </div>
    </section>
  )
}