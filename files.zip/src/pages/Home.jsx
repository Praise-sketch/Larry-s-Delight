import React from 'react'
import Hero from '../components/Hero'
import ProductCard from '../components/ProductCard'

const sampleProducts = [
  {
    id: 1,
    name: 'Mango Bliss',
    description: 'Fresh mangoes, lightly sweetened, no preservatives.',
    price: '$3.50',
    image: 'https://images.unsplash.com/photo-1601004890684-d8cbf643f5f2?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=0d0d7f6ba7e0f7b1d2d7b0c6a2b5e1c3'
  },
  {
    id: 2,
    name: 'Berry Zing',
    description: 'A mix of blueberries, raspberries and strawberries.',
    price: '$3.75',
    image: 'https://images.unsplash.com/photo-1542444459-db4f3c5d4b1f?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=8b3f8c6c3f6c2a1a80f8b3a2f6e4d2c5'
  },
  {
    id: 3,
    name: 'Green Detox',
    description: 'Cucumber, apple, and a hint of mint for a clean boost.',
    price: '$4.00',
    image: 'https://images.unsplash.com/photo-1545239351-1141bd82e8a6?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=aa2f6b68a2d9b3f4e5a2b1c3d4e5f6a7'
  }
]

export default function Home() {
  return (
    <>
      <Hero />
      <section className="py-12">
        <div className="container">
          <h2 className="text-2xl font-semibold">Popular Products</h2>
          <p className="text-gray-600 mt-2">Handcrafted and packed with real fruit.</p>

          <div className="mt-6 grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
            {sampleProducts.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>
    </>
  )
}